
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

class Node {

    private String name;
    private int x;
    private int y;
    private List<Edge> edges;

    public Node(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.edges = new ArrayList<>();
    }

    public void addEdge(Edge edge) {
        edges.add(edge);
    }

    public String getName() {
        return name;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public List<Edge> getEdges() {
        return edges;
    }
}

class Edge {

    private Node source;
    private Node destination;
    private double weight;

    public Edge(Node source, Node destination, double weight) {
        this.source = source;
        this.destination = destination;
        this.weight = weight;
    }

    public Node getSource() {
        return source;
    }

    public Node getDestination() {
        return destination;
    }

    public double getWeight() {
        return weight;
    }
}

class MapPanel extends JPanel {

    private List<Node> nodes;
    private Node startNode;
    private Node endNode;
    private Map<Node, Double> distances;
    private Map<Node, Node> previousNodes;

    public MapPanel(List<Node> nodes) {
        this.nodes = nodes;
        this.startNode = null;
        this.endNode = null;
        this.distances = new HashMap<>();
        this.previousNodes = new HashMap<>();

        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.WHITE);
        addMouseListener(new NodeClickListener());
    }

    public Node getStartNode() {
        return startNode;
    }

    public void setStartNode(Node startNode) {
        this.startNode = startNode;
        repaint();
    }

    public Node getEndNode() {
        return endNode;
    }

    public void setEndNode(Node endNode) {
        this.endNode = endNode;
        repaint();
    }

    public void calculateShortestPath() {
        distances.clear();
        previousNodes.clear();

        Queue<Node> queue = new PriorityQueue<>((n1, n2) -> Double.compare(distances.get(n1), distances.get(n2)));

        for (Node node : nodes) {
            distances.put(node, Double.POSITIVE_INFINITY);
            previousNodes.put(node, null);
        }

        distances.put(startNode, 0.0);
        queue.add(startNode);

        while (!queue.isEmpty()) {
            Node current = queue.poll();

            if (current == endNode) {
                break;
            }

            for (Edge edge : current.getEdges()) {
                Node neighbor = edge.getDestination();
                double newDistance = distances.get(current) + edge.getWeight();

                if (newDistance < distances.get(neighbor)) {
                    distances.put(neighbor, newDistance);
                    previousNodes.put(neighbor, current);
                    queue.add(neighbor);
                }
            }
        }
    }

    public Map<Node, Double> getDistances() {
        return distances;
    }

    public List<Node> getPath() {
        List<Node> path = new ArrayList<>();
        Node current = endNode;

        while (current != null) {
            path.add(0, current);
            current = previousNodes.get(current);
        }

        return path;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (Node node : nodes) {
            int x = node.getX();
            int y = node.getY();

            g.setColor(Color.BLACK);
            g.drawString(node.getName(), x + 10, y - 10);
            g.drawOval(x - 5, y - 5, 10, 10);
        }

        if (startNode != null) {
            int x = startNode.getX();
            int y = startNode.getY();

            g.setColor(Color.RED);
            g.fillOval(x - 5, y - 5, 10, 10);
        }

        if (endNode != null) {
            int x = endNode.getX();
            int y = endNode.getY();

            g.setColor(Color.GREEN);
            g.fillOval(x - 5, y - 5, 10, 10);

            g.setColor(Color.BLUE);
            List<Node> path = getPath();

            for (int i = 0; i < path.size() - 1; i++) {
                Node currentNode = path.get(i);
                Node nextNode = path.get(i + 1);
                g.drawLine(currentNode.getX(), currentNode.getY(), nextNode.getX(), nextNode.getY());
            }
        }
    }

    private class NodeClickListener extends MouseAdapter {

        @Override
        public void mouseClicked(MouseEvent e) {
            int mouseX = e.getX();
            int mouseY = e.getY();

            for (Node node : nodes) {
                int nodeX = node.getX();
                int nodeY = node.getY();

                if (mouseX >= nodeX - 5 && mouseX <= nodeX + 5 && mouseY >= nodeY - 5 && mouseY <= nodeY + 5) {
                    if (startNode == null) {
                        setStartNode(node);
                    } else if (endNode == null) {
                        setEndNode(node);
                    }
                    break;
                }
            }
        }
    }

    public void showShortestPath() {
        calculateShortestPath();
        repaint();
    }
}

public class MapApplication {

    private JFrame frame;
    private MapPanel mapPanel;
    private JLabel distanceLabel;
    private JLabel pathLabel;
    private JButton shortestPathButton;

    public MapApplication() {
        frame = new JFrame("Map Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mapPanel = new MapPanel(createNodes());
        frame.add(mapPanel);

        JButton calculateButton = new JButton("Start");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateShortestPath();
            }
        });

        shortestPathButton = new JButton("Directions");
        shortestPathButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showShortestPath();
            }
        });

        distanceLabel = new JLabel();
        pathLabel = new JLabel();

        JPanel controlPanel = new JPanel();
        controlPanel.add(calculateButton);
        controlPanel.add(shortestPathButton);
        controlPanel.add(distanceLabel);
        controlPanel.add(pathLabel);

        frame.add(controlPanel, "South");

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private List<Node> createNodes() {

        List<Node> nodes = new ArrayList<>();
        nodes.add(new Node("Uttora", 50, 50));
        nodes.add(new Node("Gausia", 150, 100));
        nodes.add(new Node("Kuril", 200, 200));
        nodes.add(new Node("Kanchan", 100, 300));
        nodes.add(new Node("Savar", 300, 300));
        nodes.add(new Node("Shonirkara", 200, 50));
        nodes.add(new Node("Raerbag", 250, 100));
        nodes.add(new Node("Jatrabari", 150, 200));
        nodes.add(new Node("Matuail Medical", 250, 250));
        nodes.add(new Node("Signboard", 50, 150));
        nodes.add(new Node("Saddam Market", 150, 250));
        nodes.add(new Node("Shanarpar", 350, 100));
        nodes.add(new Node("Mouchak", 350, 250));
        nodes.add(new Node("Chittagong Road", 400, 150));
        nodes.add(new Node("Kachpur", 400, 250));
        nodes.add(new Node("Tarabo", 450, 200));
        nodes.add(new Node("Borabo", 500, 200));
        nodes.add(new Node("Rupsi", 550, 200));
        nodes.add(new Node("Borpa", 600, 200));
        nodes.add(new Node("Moikuli", 650, 200));
        nodes.add(new Node("Kornogop", 700, 200));
        nodes.add(new Node("Konapara", 750, 200));
        nodes.add(new Node("Staffquarter", 800, 200));
        nodes.add(new Node("Farmer Mor", 850, 200));
        nodes.add(new Node("Mirpur", 700, 50));
        nodes.add(new Node("Dhanmondi", 700, 100));
        nodes.add(new Node("Gulshan", 750, 150));
        nodes.add(new Node("Banani", 800, 150));
        nodes.add(new Node("Badda", 850, 150));
        nodes.add(new Node("Rampura", 900, 150));
        nodes.add(new Node("Komlapur", 950, 150));
        nodes.add(new Node("Gulistan", 1000, 150));
        nodes.add(new Node("Elephant Road", 700, 250));
        nodes.add(new Node("New Market", 750, 250));
        nodes.add(new Node("Shahabag", 800, 250));

        nodes.get(0).addEdge(new Edge(nodes.get(0), nodes.get(1), 50));
        nodes.get(1).addEdge(new Edge(nodes.get(1), nodes.get(2), 70));
        nodes.get(2).addEdge(new Edge(nodes.get(2), nodes.get(3), 90));
        nodes.get(3).addEdge(new Edge(nodes.get(3), nodes.get(4), 80));
        // Additional edges
        nodes.get(4).addEdge(new Edge(nodes.get(2), nodes.get(5), 30));
        nodes.get(5).addEdge(new Edge(nodes.get(5), nodes.get(6), 40));
        nodes.get(6).addEdge(new Edge(nodes.get(6), nodes.get(7), 60));
        nodes.get(7).addEdge(new Edge(nodes.get(7), nodes.get(8), 50));
        nodes.get(8).addEdge(new Edge(nodes.get(8), nodes.get(9), 70));
        nodes.get(9).addEdge(new Edge(nodes.get(9), nodes.get(10), 80));
        nodes.get(10).addEdge(new Edge(nodes.get(10), nodes.get(11), 100));
        nodes.get(11).addEdge(new Edge(nodes.get(11), nodes.get(12), 90));
        nodes.get(12).addEdge(new Edge(nodes.get(12), nodes.get(13), 80));
        nodes.get(13).addEdge(new Edge(nodes.get(13), nodes.get(14), 70));
        nodes.get(14).addEdge(new Edge(nodes.get(14), nodes.get(15), 60));
        nodes.get(15).addEdge(new Edge(nodes.get(15), nodes.get(16), 50));
        nodes.get(16).addEdge(new Edge(nodes.get(16), nodes.get(17), 40));
        nodes.get(17).addEdge(new Edge(nodes.get(17), nodes.get(18), 30));
        nodes.get(18).addEdge(new Edge(nodes.get(18), nodes.get(19), 20));
        nodes.get(19).addEdge(new Edge(nodes.get(19), nodes.get(20), 10));
        nodes.get(20).addEdge(new Edge(nodes.get(20), nodes.get(21), 10));
        nodes.get(21).addEdge(new Edge(nodes.get(21), nodes.get(22), 20));
        nodes.get(22).addEdge(new Edge(nodes.get(22), nodes.get(23), 30));
        nodes.get(23).addEdge(new Edge(nodes.get(23), nodes.get(24), 40));
        nodes.get(24).addEdge(new Edge(nodes.get(24), nodes.get(25), 50));
        nodes.get(25).addEdge(new Edge(nodes.get(25), nodes.get(26), 60));
        nodes.get(26).addEdge(new Edge(nodes.get(26), nodes.get(27), 70));
        nodes.get(27).addEdge(new Edge(nodes.get(27), nodes.get(28), 80));
        nodes.get(28).addEdge(new Edge(nodes.get(28), nodes.get(29), 90));
        nodes.get(29).addEdge(new Edge(nodes.get(29), nodes.get(30), 100));
        nodes.get(30).addEdge(new Edge(nodes.get(30), nodes.get(31), 110));
        nodes.get(31).addEdge(new Edge(nodes.get(31), nodes.get(32), 120));
        nodes.get(32).addEdge(new Edge(nodes.get(32), nodes.get(33), 130));
        nodes.get(33).addEdge(new Edge(nodes.get(33), nodes.get(34), 140));

        return nodes;
    }

    private void calculateShortestPath() {
        Node startNode = mapPanel.getStartNode();
        Node endNode = mapPanel.getEndNode();

        if (startNode != null && endNode != null) {
            mapPanel.calculateShortestPath();

            // Get the shortest path distance and path
            Map<Node, Double> distances = mapPanel.getDistances();
            List<Node> path = mapPanel.getPath();

            // Display the shortest path distance
            double shortestDistance = distances.get(endNode);
            distanceLabel.setText("Distance: " + shortestDistance);

            // Display the path
            StringBuilder pathText = new StringBuilder();
            for (int i = 0; i < path.size(); i++) {
                Node node = path.get(i);
                pathText.append(node.getName());
                if (i < path.size() - 1) {
                    pathText.append(" -> ");
                }
            }
            pathLabel.setText("Path: " + pathText.toString());
        } else {
            distanceLabel.setText("Distance: ");
            pathLabel.setText("Path: ");
        }
    }

    private void showShortestPath() {
        Node startNode = mapPanel.getStartNode();
        Node endNode = mapPanel.getEndNode();

        if (startNode != null && endNode != null) {
            mapPanel.showShortestPath();

            // Get the shortest path distance and path
            Map<Node, Double> distances = mapPanel.getDistances();
            List<Node> path = mapPanel.getPath();

            // Display the shortest path distance
            double shortestDistance = distances.get(endNode);
            distanceLabel.setText("Distance: " + shortestDistance);

            // Display the path
            StringBuilder pathText = new StringBuilder();
            for (int i = 0; i < path.size(); i++) {
                Node node = path.get(i);
                pathText.append(node.getName());
                if (i < path.size() - 1) {
                    pathText.append(" -> ");
                }
            }
            pathLabel.setText("Path: " + pathText.toString());
        } else {
            distanceLabel.setText("Distance: ");
            pathLabel.setText("Shortest Path: ");
        }
    }

    public static void main(String[] args) {
        new MapApplication();
    }
}
