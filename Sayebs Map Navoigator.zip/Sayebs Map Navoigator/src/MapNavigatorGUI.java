
import javax.swing.*;
import java.awt.*;

public class MapNavigatorGUI extends JFrame {
    private MapApplication mapApp;

    public MapNavigatorGUI() {
        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Sayeb's Map Navigator");

        // Create the panel
        JPanel panel = new JPanel();
        panel.setBackground(Color.BLACK);

        // Create the label for the text
        JLabel label = new JLabel("Welcome to Sayeb's Map Navigator");
        label.setForeground(Color.WHITE);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 24f)); // Set font and size

        // Add the label to the panel
        panel.add(label);

        // Create the button to enter the map application
        JButton enterButton = new JButton("Get Inside");
        enterButton.addActionListener(e -> enterMapApplication());

        // Add the button to the panel
        panel.add(enterButton);

        // Add the panel to the frame
        getContentPane().add(panel);

        // Pack and display the frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void enterMapApplication() {
        mapApp = new MapApplication();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MapNavigatorGUI::new);
    }
}
